package com.squad.roboticRovers;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RoboticRoversApplication {

	public static void main(String[] args) {
		SpringApplication.run(RoboticRoversApplication.class, args);
	}

}
