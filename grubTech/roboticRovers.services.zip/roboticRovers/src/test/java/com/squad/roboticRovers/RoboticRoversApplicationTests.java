package com.squad.roboticRovers;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RoboticRoversApplicationTests {

	@Test
	void contextLoads() {
	}

}
